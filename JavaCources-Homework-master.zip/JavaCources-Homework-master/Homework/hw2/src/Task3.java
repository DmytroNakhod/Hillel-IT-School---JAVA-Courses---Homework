public class Task3
{
   public static void main(String[] args) {
	
		int[] array;
		
		array = new int[] { 1, -3, 0, -6, 7 };
		
		for(int i = 0; i < array.length; i++)
		{	
		System.out.println( array[i] );

		}
		
		for(int i = 0; i < array.length; i++)
		{	
		System.out.print( array[i] );

		}
		
	}
}