public class Car {
    int id;
    String brand;
    int yearOfProduction;
    String color;
    long price;
    String registrationNumber;
    String model;

    public Car( int id, String brand, int yearOfProduction, String color, long  price, String registrationNumber, String model){
        this.id = id;
        this.brand = brand;
        this.yearOfProduction = yearOfProduction;
        this.color = color;
        this.price = price;
        this.registrationNumber = registrationNumber;
        this.model = model;
    }
}
