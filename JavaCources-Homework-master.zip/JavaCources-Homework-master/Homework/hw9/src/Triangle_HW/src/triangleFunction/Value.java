package triangleFunction;

import Triangle.Triangle;

public interface Value {
    double getValue(Triangle triangle);

}
