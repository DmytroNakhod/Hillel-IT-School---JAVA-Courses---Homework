package triangleFunction;

import Triangle.*;

public interface Criteria {

     boolean check(Triangle triangle);
}
