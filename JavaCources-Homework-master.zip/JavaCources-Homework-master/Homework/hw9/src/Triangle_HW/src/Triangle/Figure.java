package Triangle;

public abstract class Figure {
    protected abstract double findArea();

    protected abstract double findPerimeter();
}
